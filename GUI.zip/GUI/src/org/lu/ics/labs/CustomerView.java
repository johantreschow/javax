package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.JButton;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;

import javax.swing.JScrollPane;
import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.util.ArrayList;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class CustomerView {

	private JFrame frmCustomerView;
	private Controller controller;
	private Customer c = new Customer();

	/**
	 * Launch the application.
	 */
	private DefaultTableModel dtmOrders;
	private JTextField tfSearch;

	/**
	 * Create the application.
	 */
	public CustomerView(Controller c) {
		this.controller = c;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCustomerView = new JFrame();
		frmCustomerView.setTitle("Kund");
		frmCustomerView.setBounds(100, 100, 685, 588);
		frmCustomerView.getContentPane().setLayout(null);

		JLabel lblName = new JLabel("Namn: ");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblName.setBounds(28, 36, 436, 14);
		frmCustomerView.getContentPane().add(lblName);

		JLabel lblAdress = new JLabel("Adress: ");
		lblAdress.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblAdress.setBounds(28, 61, 436, 14);
		frmCustomerView.getContentPane().add(lblAdress);

		JLabel lblPhoneNumber = new JLabel("Telefonnummer:");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPhoneNumber.setBounds(28, 86, 436, 14);
		frmCustomerView.getContentPane().add(lblPhoneNumber);

		JButton btnAddOrder = new JButton("L\u00E4gg till Order");
		btnAddOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (c == null) {
					JOptionPane.showMessageDialog(frmCustomerView,
							"Ingen kund vald", "Fel", 2);
				} else {
					OrderWindow orderWindow = new OrderWindow(controller, c);
					orderWindow.setVisible(true);
				}

			}
		});
		btnAddOrder.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnAddOrder.setBounds(38, 368, 114, 23);
		frmCustomerView.getContentPane().add(btnAddOrder);

		JScrollPane spOrders = new JScrollPane();
		spOrders.setBounds(28, 136, 631, 188);
		frmCustomerView.getContentPane().add(spOrders);

		dtmOrders = new DefaultTableModel();
		String[] columnNames = new String[] { "Ordernummer", "Datum", "Status" };
		dtmOrders.setColumnIdentifiers(columnNames);
		JTable tblOrders = new JTable(dtmOrders);
		spOrders.setViewportView(tblOrders);

		tfSearch = new JTextField();
		tfSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				tfSearch.setText("");
			}
		});
		tfSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		tfSearch.setText("S\u00F6k kund...");
		tfSearch.setBounds(25, 11, 86, 20);
		frmCustomerView.getContentPane().add(tfSearch);
		tfSearch.setColumns(10);

		JButton btnSearch = new JButton("S\u00F6k");
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c = controller.getCustomer(tfSearch.getText());
				if (c == null) {
					JOptionPane.showMessageDialog(frmCustomerView,
							"Kund kan inte hittas.", "Fel", 2);
				} else {
					lblName.setText("Namn: " + c.getName());
					lblAdress.setText("Adress: " + c.getAdress());
					lblPhoneNumber.setText("Telefonnummer: "
							+ c.getPhoneNumber());

					addOrderToDTM(c);
				}
			}
		});
		btnSearch.setBounds(126, 10, 89, 23);
		frmCustomerView.getContentPane().add(btnSearch);

		JButton btnCancel = new JButton("Avbryt");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmCustomerView.setVisible(false);
				frmCustomerView.dispose();
			}
		});
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnCancel.setBounds(570, 516, 89, 23);
		frmCustomerView.getContentPane().add(btnCancel);

		JButton btnEditCustomer = new JButton("Redigera Kund");
		btnEditCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (c == null) {
					JOptionPane.showMessageDialog(frmCustomerView,
							"Kan ej redigera kund d� ingen kund har valts.",
							" ", 2);
				} else {
					EditCustomerView editCustomerView = new EditCustomerView(c);
				}
			}
		});
		btnEditCustomer.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnEditCustomer.setBounds(526, 107, 114, 23);
		frmCustomerView.getContentPane().add(btnEditCustomer);
		frmCustomerView.setVisible(true);

		JButton btnEditOrder = new JButton("Redigera Order");
		btnEditOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order o;
				int selectedRow = tblOrders.getSelectedRow();
				if (selectedRow < 0) {
					JOptionPane.showMessageDialog(frmCustomerView,
							"Ingen order att redigera.", " ", 2);
				} else {
					o = c.getOrders().get(selectedRow);
					EditOrderWindow editOrderWindow = new EditOrderWindow(o, controller);
					addOrderToDTM(c);
				}

			}
		});
		btnEditOrder.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnEditOrder.setBounds(38, 334, 114, 23);
		frmCustomerView.getContentPane().add(btnEditOrder);
		
		JButton btnRemoveOrder = new JButton("Ta bort order");
		btnRemoveOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedRow = tblOrders.getSelectedRow();
				if (selectedRow < 0) {
					JOptionPane.showMessageDialog(frmCustomerView,
							"Ingen order att redigera.", " ", 2);
				} else {
					c.removeOrder(c.getOrders().get(selectedRow));
					addOrderToDTM(c);
				}

				
			}
		});
		btnRemoveOrder.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnRemoveOrder.setBounds(38, 402, 114, 23);
		frmCustomerView.getContentPane().add(btnRemoveOrder);

	}

	private void addOrderToDTM(Customer c) {
		dtmOrders.setRowCount(0);
		for (Order o : c.getOrders()) {
			String[] sa = new String[] { o.getOrderId(), o.getDate(),
					o.getStatus() };
			dtmOrders.addRow(sa);

		}
	}

}
