package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class MainView {
	
	private Controller controller = new Controller();
	private JFrame frmSchinnOchBehn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainView window = new MainView();
					window.frmSchinnOchBehn.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainView() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSchinnOchBehn = new JFrame();
		frmSchinnOchBehn.setTitle("Schinn och Behn AB");
		frmSchinnOchBehn.setBounds(100, 100, 689, 590);
		frmSchinnOchBehn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSchinnOchBehn.getContentPane().setLayout(null);
		
		JButton btnAddCustomer = new JButton("L\u00E4gg till kund");
		btnAddCustomer.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnAddCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NewCustomerView addCustomer = new NewCustomerView(controller);
			}
		});
		btnAddCustomer.setBounds(10, 118, 170, 50);
		frmSchinnOchBehn.getContentPane().add(btnAddCustomer);
		
		JButton btnAddProduct = new JButton("L\u00E4gg till produkt");
		btnAddProduct.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnAddProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewProductView addProduct = new NewProductView(controller);
			}
		});
		btnAddProduct.setBounds(250, 118, 170, 50);
		frmSchinnOchBehn.getContentPane().add(btnAddProduct);
		
		JButton btnAddSupplier = new JButton("L\u00E4gg till leverant\u00F6r");
		btnAddSupplier.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnAddSupplier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewSupplierView addSupplier = new NewSupplierView(controller);
			}
		});
		btnAddSupplier.setBounds(493, 118, 170, 50);
		frmSchinnOchBehn.getContentPane().add(btnAddSupplier);
		
		JButton btnSearchCustomer = new JButton("S\u00F6k kund");
		btnSearchCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomerView customerView = new CustomerView(controller);
			}
		});
		btnSearchCustomer.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSearchCustomer.setBounds(10, 179, 170, 50);
		frmSchinnOchBehn.getContentPane().add(btnSearchCustomer);
		
		JButton btnSearchProduct = new JButton("S\u00F6k produkt");
		btnSearchProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProductView productView = new ProductView(controller);
			}
		});
		btnSearchProduct.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSearchProduct.setBounds(250, 179, 170, 50);
		frmSchinnOchBehn.getContentPane().add(btnSearchProduct);
		
		JButton btnSearchSupplier = new JButton("S\u00F6k Leverant\u00F6r");
		btnSearchSupplier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SupplierView supplierView = new SupplierView(controller);
			}
		});
		btnSearchSupplier.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSearchSupplier.setBounds(493, 179, 170, 50);
		frmSchinnOchBehn.getContentPane().add(btnSearchSupplier);
		
//		JButton btnShowBuyOrders = new JButton("Visa planerade ink\u00F6p");
//		btnShowBuyOrders.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				PlannedBuyOrders plannedBuyOrders = new PlannedBuyOrders(controller);
//			}
//		});
//		btnShowBuyOrders.setFont(new Font("Tahoma", Font.PLAIN, 11));
//		btnShowBuyOrders.setBounds(10, 384, 142, 23);
//		frmSchinnOchBehn.getContentPane().add(btnShowBuyOrders);
//		
//		JButton btnShowWarehouseOrders = new JButton("Visa order per lager");
//		btnShowWarehouseOrders.setFont(new Font("Tahoma", Font.PLAIN, 11));
//		btnShowWarehouseOrders.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//			}
//		});
//		btnShowWarehouseOrders.setBounds(10, 442, 142, 23);
//		frmSchinnOchBehn.getContentPane().add(btnShowWarehouseOrders);
		
		JLabel lblNewLabel = new JLabel("Kund");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 35));
		lblNewLabel.setBounds(10, 46, 170, 61);
		frmSchinnOchBehn.getContentPane().add(lblNewLabel);
		
		JLabel lblProdukt = new JLabel("Produkt");
		lblProdukt.setHorizontalAlignment(SwingConstants.CENTER);
		lblProdukt.setFont(new Font("Tahoma", Font.PLAIN, 35));
		lblProdukt.setBounds(230, 46, 210, 61);
		frmSchinnOchBehn.getContentPane().add(lblProdukt);
		
		JLabel lblLeverantr = new JLabel("Leverant\u00F6r");
		lblLeverantr.setHorizontalAlignment(SwingConstants.CENTER);
		lblLeverantr.setFont(new Font("Tahoma", Font.PLAIN, 35));
		lblLeverantr.setBounds(453, 46, 250, 61);
		frmSchinnOchBehn.getContentPane().add(lblLeverantr);
		
		Product julskinka = new Product();
		Product sylta = new Product();
		Product prinskorv = new Product();
		Product leverpastej = new Product();
		Product kyckling = new Product();
		Product rostbiff = new Product();
		
		
		julskinka.setName("Julskinka");
		julskinka.setPrice(50);
		julskinka.setWeight(2);
		julskinka.setAmountInStock(0);
		julskinka.addRetailName("Jontes Julskinka");
		julskinka.setProductManager("Jonathan Koscher");
		julskinka.setPrepMethod("H�ngm�ra 1 dag");
		
		sylta.setName("Sylta");
		sylta.setPrice(120);
		sylta.setWeight(0.500);
		sylta.setAmountInStock(0);
		sylta.addRetailName("Sivs Sylta");
		sylta.addRetailName("Sommar Sylta");
		sylta.setProductManager("Simon Sultan");
		sylta.setPrepMethod("F�rpacka syltan");
		
		prinskorv.setName("Prinskorv");
		prinskorv.setPrice(90);
		prinskorv.setWeight(1);
		prinskorv.setAmountInStock(0);
		prinskorv.addRetailName("Petters Prinskorv");
		prinskorv.addRetailName("Prinsens Korvar Deluxe");
		prinskorv.addRetailName("En Prinsessas Korvar");
		prinskorv.setProductManager("Petronella Orwar");
		prinskorv.setPrepMethod("Blanda ihop ingredienserna (1kg korv, 500g mj�l, 1L vatten), snitta korven, f�rpacka den");
		
		leverpastej.setName("Leverpastej");
		leverpastej.setPrice(110.50);
		leverpastej.setWeight(1);
		leverpastej.setAmountInStock(0);
		leverpastej.addRetailName("Lisas Julpastej");
		leverpastej.addRetailName("Lyx Leverpastej");
		leverpastej.setProductManager("Leif Mannerstr�m");
		leverpastej.setPrepMethod("Blanda 1kg lever och 500g pastej, f�rpacka");
		
		kyckling.setName("Kyckling");
		kyckling.setPrice(250);
		kyckling.setWeight(5);
		kyckling.setAmountInStock(0);
		kyckling.addRetailName("Kalles Kyckling");
		kyckling.addRetailName("Kronkyckling Krav");
		kyckling.setProductManager("Katarina Wavrinka");
		kyckling.setPrepMethod("Krydda, frys in, f�rpacka");
		
		rostbiff.setName("Rostbiff");
		rostbiff.setPrice(30);
		rostbiff.setWeight(1);
		rostbiff.setAmountInStock(0);
		rostbiff.addRetailName("Rolfs Robusta Rostbiff");
		rostbiff.addRetailName("Reabiff");
		rostbiff.setProductManager("Robert Biff");
		rostbiff.setPrepMethod("Krydda rostbiff med peppar");
		
		controller.addProduct("Julskinka", julskinka);
		controller.addProduct("Sylta", sylta);
		controller.addProduct("Prinskorv", prinskorv);
		controller.addProduct("Leverpastej", leverpastej);
		controller.addProduct("Kyckling", kyckling);
		controller.addProduct("Rostbiff", rostbiff);
		
		Customer ikea = new Customer();
		Customer widerbergs = new Customer();
		Customer soderbergs = new Customer();
		
		ikea.setName("Ikea AB");
		ikea.setPhoneNumber("1140050");
		ikea.setAdress("Kamprad V�gen 1");
		ikea.setSalesTerms("5% p� allt vid best�llning �ver 50 000kr");
		
		widerbergs.setName("Widerbergs K�tt AB");
		widerbergs.setPhoneNumber("2222005");
		widerbergs.setAdress("Sankt Petri Kyrkogata 5");
		widerbergs.setSalesTerms("3% vid best�llning �ver 100 valfria varor");
		
		soderbergs.setName("S�derbergs Delikatesser KB");
		soderbergs.setPhoneNumber("5050352");
		soderbergs.setAdress("Stora S�dergatan 19");
		soderbergs.setSalesTerms("Ingen rabbatt");
		
		controller.addCustomer(ikea);
		controller.addCustomer(widerbergs);
		controller.addCustomer(soderbergs);
		
		Warehouse lund = new Warehouse();
		Warehouse skara = new Warehouse();
		Warehouse borlange = new Warehouse();
		
		lund.setName("Lund");
		lund.setAdress("Charkv�gen 8");
		lund.setPhoneNumber("345278");
		
		skara.setName("Skara");
		skara.setAdress("Korvgatan 5");
		skara.setPhoneNumber("547728");
		
		borlange.setName("Borl�nge");
		borlange.setAdress("Slaktargr�nd 2");
		borlange.setPhoneNumber("394587");
		
		controller.addWarehouse(lund);
		controller.addWarehouse(skara);
		controller.addWarehouse(borlange);
		
		Supplier flyinge = new Supplier();
		Supplier johanssons = new Supplier();
		Supplier skinkimporten = new Supplier();
		
		flyinge.setName("Flyinge K�ttproduktion");
		flyinge.setPhoneNumber("046500200");
		flyinge.setEmail("johannes@flyinge.se");
		
		johanssons.setName("Johanssons Korv & Chark");
		johanssons.setPhoneNumber("0762525299");
		johanssons.setEmail("johanssons@hotmail.com");
		
		skinkimporten.setName("Italienska Skinkimporten AB");
		skinkimporten.setPhoneNumber("0300251251");
		skinkimporten.setEmail("iberico@business.it");
		
		controller.addSupplier(flyinge);
		controller.addSupplier(johanssons);
		controller.addSupplier(skinkimporten);
	}
}
