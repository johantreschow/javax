package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UpdateStockView {

	private JFrame frmUppdateraLagersaldo;
	private Controller controller;
	private Product product;
	private JTextField textField;

	/**
	 * Create the application.
	 */
	public UpdateStockView(Controller c, Product p) {
		controller = c;
		product = p;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmUppdateraLagersaldo = new JFrame();
		frmUppdateraLagersaldo.setTitle("Uppdatera Lagersaldo f�r " + product.getName());
		frmUppdateraLagersaldo.setBounds(100, 100, 450, 300);
		frmUppdateraLagersaldo.getContentPane().setLayout(null);
		
		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.setBounds(302, 29, 122, 20);
		frmUppdateraLagersaldo.getContentPane().add(comboBox);
		
		JLabel lblWarehouse = new JLabel("Lager:");
		lblWarehouse.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblWarehouse.setBounds(259, 32, 46, 14);
		frmUppdateraLagersaldo.getContentPane().add(lblWarehouse);
		
		JLabel lblAmountInStock = new JLabel("Antal i lager: ");
		lblAmountInStock.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblAmountInStock.setBounds(10, 32, 215, 14);
	
		frmUppdateraLagersaldo.getContentPane().add(lblAmountInStock);
		
		textField = new JTextField();
		textField.setBounds(302, 81, 86, 20);
		frmUppdateraLagersaldo.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnLggTill = new JButton("L\u00E4gg Till");
		btnLggTill.setBounds(203, 80, 89, 23);
		frmUppdateraLagersaldo.getContentPane().add(btnLggTill);
		btnLggTill.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Warehouse w = controller.getWarehouse(comboBox.getSelectedIndex());
				w.addProduct(product);
				product = w.getProduct(product.getName());
				w.addStock(product, Integer.parseInt(textField.getText()));
				lblAmountInStock.setText("Antal i Lager: " + product.getAmountInStock());
			}
		});
		
		
		JButton btnTaBort = new JButton("Ta Bort");
		btnTaBort.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Warehouse w = controller.getWarehouse(comboBox.getSelectedIndex());
				w.addProduct(product);
				product = w.getProduct(product.getName());
				w.addStock(product, -1 * Integer.parseInt(textField.getText()));
				lblAmountInStock.setText("Antal i Lager: " + product.getAmountInStock());
			}
			
		});
		btnTaBort.setBounds(203, 114, 89, 23);
		frmUppdateraLagersaldo.getContentPane().add(btnTaBort);
		
		JButton btnKlar = new JButton("Klar");
		btnKlar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmUppdateraLagersaldo.setVisible(false);
				frmUppdateraLagersaldo.dispose();
			}
		});
		btnKlar.setBounds(10, 228, 89, 23);
		frmUppdateraLagersaldo.getContentPane().add(btnKlar);
		for (Warehouse w : controller.getWarehouses().getWarehouses()) {
			comboBox.addItem(w.getName());
		}
		frmUppdateraLagersaldo.setVisible(true);

	}
}
