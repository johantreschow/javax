package org.lu.ics.labs;

import java.util.ArrayList;

public class Warehouse {
	private String name;
	private String adress;
	private String phoneNumber;
	private ArrayList<Product> products = new ArrayList<>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public ArrayList<Product> getProducts() {
		return products;
	}

	public void setProducts(ArrayList<Product> products) {
		this.products = products;
	}

	public void addProduct(Product product) {
		products.add(product);
	}

	public void removeProduct(Product product) {
		products.remove(product);
	}
	
	public Product getProduct(String name){
		for(Product p : products){
			if (p.getName().equals(name)){
				return p;
			}
		}
		return null;
		
	}
	
	public void addStock(Product p, int amount){
			p.setAmountInStock(p.getAmountInStock() + amount);
		
	}
}