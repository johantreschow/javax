package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SupplierView {

	private JFrame frmSupplierView;
	private JTextField textFieldSearch;
	private Controller controller;
	private JButton btnCancel;
	private Supplier supplier;

	/**
	 * Create the application.
	 */
	public SupplierView(Controller c) {
		this.controller = c;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSupplierView = new JFrame();
		frmSupplierView.setTitle("Leverant\u00F6r");
		frmSupplierView.setBounds(100, 100, 450, 300);
		frmSupplierView.getContentPane().setLayout(null);
		
		textFieldSearch = new JTextField();
		textFieldSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				textFieldSearch.setText("");
			}
		});
		textFieldSearch.setText("S\u00F6k Leverant\u00F6r...");
		textFieldSearch.setBounds(10, 11, 114, 20);
		frmSupplierView.getContentPane().add(textFieldSearch);
		textFieldSearch.setColumns(10);
		
		JLabel lblName = new JLabel("Namn: ");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblName.setBounds(10, 53, 395, 14);
		frmSupplierView.getContentPane().add(lblName);
		
		JLabel lblPhoneNumber = new JLabel("Telefonnummer: ");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPhoneNumber.setBounds(10, 81, 395, 14);
		frmSupplierView.getContentPane().add(lblPhoneNumber);
		
		JLabel lblEmail = new JLabel("E-mail:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblEmail.setBounds(10, 112, 395, 14);
		frmSupplierView.getContentPane().add(lblEmail);
		
		JButton btnSearch = new JButton("S\u00F6k");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textFieldSearch.getText().length() > 0){
					supplier = controller.getSupplier(textFieldSearch.getText());
					if (supplier == null){
						JOptionPane.showMessageDialog(frmSupplierView,
								"Leverant�ren kan inte hittas", " ", 2);
					} else {
					lblName.setText("Namn: " + supplier.getName());
					lblPhoneNumber.setText("Telefonnummer: " + supplier.getPhoneNumber());
					lblEmail.setText("E-mail: " + supplier.getEmail());
					}
				}
			}
		});
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSearch.setBounds(159, 10, 89, 23);
		frmSupplierView.getContentPane().add(btnSearch);
		
		btnCancel = new JButton("Avbryt");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmSupplierView.setVisible(false);
				frmSupplierView.dispose();
			}
		});
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnCancel.setBounds(335, 228, 89, 23);
		frmSupplierView.getContentPane().add(btnCancel);
		
		frmSupplierView.setVisible(true);
	}

}
