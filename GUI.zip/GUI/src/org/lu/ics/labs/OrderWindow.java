package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JScrollPane;

public class OrderWindow extends JFrame {

	// private JFrame frmOrderWindow;
	private JTextField textFieldProduct;
	private JTextField textFieldAmount;
	private Controller controller;
	private ArrayList<OrderRow> orderRows = new ArrayList<OrderRow>();
	private Customer customer = new Customer();
	private Order order;
	JTable tblOrderRows;

	/**
	 * Launch the application.
	 */
	private DefaultTableModel dtmOrderRows;
	DefaultTableModel tm;
	private JButton btnAvbryt;
	private JTable table;
	private JButton btnggTill;

	/**
	 * Create the application.
	 */
	public OrderWindow(Controller c, Customer customer) {
		controller = c;
		this.customer = customer;
		order = new Order(controller.getOrderId());
		order.setCustomer(customer);
		initialize(dtmOrderRows);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(DefaultTableModel dtmOrders) {
		// frmOrderWindow = new JFrame();
		setTitle("Ny order");
		setBounds(100, 100, 450, 481);
		getContentPane().setLayout(null);

		textFieldProduct = new JTextField();
		textFieldProduct.setBounds(61, 11, 86, 20);
		getContentPane().add(textFieldProduct);
		textFieldProduct.setColumns(10);

		JLabel lblProduct = new JLabel("Produkt: ");
		lblProduct.setBounds(10, 14, 46, 14);
		lblProduct.setFont(new Font("Tahoma", Font.PLAIN, 11));
		getContentPane().add(lblProduct);

		textFieldAmount = new JTextField();
		textFieldAmount.setBounds(191, 11, 86, 20);
		textFieldAmount.setColumns(10);
		getContentPane().add(textFieldAmount);

		JLabel lblAmount = new JLabel("Antal:");
		lblAmount.setBounds(157, 14, 46, 14);
		lblAmount.setFont(new Font("Tahoma", Font.PLAIN, 11));
		this.getContentPane().add(lblAmount);

		btnAvbryt = new JButton("Avbryt");
		btnAvbryt.setBounds(335, 409, 89, 23);
		btnAvbryt.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnAvbryt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonOne();

			}
		});
		this.getContentPane().add(btnAvbryt);

		JButton btnLggTill = new JButton("L\u00E4gg Till Produkt");
		btnLggTill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonThree();
			}
		});
		btnLggTill.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnLggTill.setBounds(311, 10, 89, 23);


		JButton btnAddOrder = new JButton("L\u00E4gg Till Order");
		btnAddOrder.setBounds(10, 409, 137, 23);
		btnAddOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonTwo();
			}
		});
		btnAddOrder.setFont(new Font("Tahoma", Font.PLAIN, 11));
		this.getContentPane().add(btnAddOrder);

		// start
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(44, 65, 380, 316);
		this.getContentPane().add(scrollPane);

		String[] columnNames = new String[] { "Namn", "Antal", "�-pris",
				"totalt pris" };

		tm = new DefaultTableModel();
		tm.setColumnIdentifiers(columnNames);
		table = new JTable(tm);
		scrollPane.setViewportView(table);

		// slut
		btnggTill = new JButton("L\u00E4gg till");
		btnggTill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonThree();
			}
		});
		btnggTill.setBounds(297, 10, 89, 23);
		getContentPane().add(btnggTill);

	}

	private void buttonOne() {
		this.setVisible(false);
		this.dispose();
	}

	private void buttonTwo() {
		if (orderRows.isEmpty()) {
			JOptionPane.showMessageDialog(this,
					"Inga produkter tillagda i ordern", "Fel", 2);
		} else {
			customer.addOrder(order);
			this.setVisible(false);
			this.dispose();
		}
	}

	private void buttonThree() {
		Product product = controller.getProduct(textFieldProduct.getText());
		if (product == null) {
			JOptionPane.showMessageDialog(this, "Produkt kan inte hittas.",
					"Fel", 2);
		} else {
			OrderRow row = new OrderRow();
			row.setProduct(product);
			row.setAmount(Integer.parseInt(textFieldAmount.getText()));
			orderRows.add(row);
			order.addOrderRow(row);
			updateDTM();
		}
	}

	public void updateDTM() {
		tm.setRowCount(0);

		for (OrderRow tmp : orderRows) {

			String[] row = {
					tmp.getProduct().getName(),
					Integer.toString(tmp.getAmount()),
					Double.toString(tmp.getProduct().getPrice()),
					Double.toString(tmp.getProduct().getPrice()
							* tmp.getAmount()) };
			tm.addRow(row);

		}

	}
}
