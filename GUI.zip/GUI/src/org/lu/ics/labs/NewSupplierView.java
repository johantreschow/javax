package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NewSupplierView {

	private JFrame frmAddSupplier;
	private JTextField textFieldEmail;
	private JTextField textFieldPhoneNumber;
	private JTextField textFieldName;
	private Controller controller;

	/**
	 * Create the application.
	 */
	public NewSupplierView(Controller c) {
		this.controller = c;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAddSupplier = new JFrame();
		frmAddSupplier.setTitle("L\u00E4gg till leverant\u00F6r");
		frmAddSupplier.setBounds(100, 100, 308, 224);
		frmAddSupplier.getContentPane().setLayout(null);
		
		textFieldEmail = new JTextField();
		textFieldEmail.setColumns(10);
		textFieldEmail.setBounds(103, 70, 86, 20);
		frmAddSupplier.getContentPane().add(textFieldEmail);
		
		JLabel lblEmail = new JLabel("E-mail:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblEmail.setBounds(10, 76, 95, 14);
		frmAddSupplier.getContentPane().add(lblEmail);
		
		JLabel lblPhoneNumber = new JLabel("Telefonnummer: ");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPhoneNumber.setBounds(10, 45, 95, 14);
		frmAddSupplier.getContentPane().add(lblPhoneNumber);
		
		textFieldPhoneNumber = new JTextField();
		textFieldPhoneNumber.setColumns(10);
		textFieldPhoneNumber.setBounds(103, 39, 86, 20);
		frmAddSupplier.getContentPane().add(textFieldPhoneNumber);
		
		textFieldName = new JTextField();
		textFieldName.setColumns(10);
		textFieldName.setBounds(103, 11, 86, 20);
		frmAddSupplier.getContentPane().add(textFieldName);
		
		JLabel lblName = new JLabel("Namn: ");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblName.setBounds(10, 17, 46, 14);
		frmAddSupplier.getContentPane().add(lblName);
		
		JButton btnAdd = new JButton("L\u00E4gg till");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Supplier s = controller.getSupplier(textFieldName.getText());
				if(s == null){
					s = new Supplier();
					s.setName(textFieldName.getText());
					s.setPhoneNumber(textFieldPhoneNumber.getText());
					s.setEmail(textFieldEmail.getText());
					if(s.getName().length() == 0 || s.getPhoneNumber().length() == 0 || s.getEmail().length() == 0){
						JOptionPane.showMessageDialog(frmAddSupplier, "Var v�nlig och fyll i alla f�lt.", " ", 2);
					} else {
						controller.addSupplier(s);
						JOptionPane.showMessageDialog(frmAddSupplier, "Leverant�r " + s.getName() + " tillagd.", " ", 1);
						frmAddSupplier.setVisible(false);
						frmAddSupplier.dispose();
					}
					
				}else {
					JOptionPane.showMessageDialog(frmAddSupplier, "Leverant�r finns redan.", "Fel", 2);
				}
				
			}
		});
		btnAdd.setBounds(10, 124, 89, 23);
		frmAddSupplier.getContentPane().add(btnAdd);
		
		JButton btnCancel = new JButton("Avbryt");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmAddSupplier.setVisible(false);
				frmAddSupplier.dispose();
			}
		});
		btnCancel.setBounds(193, 124, 89, 23);
		frmAddSupplier.getContentPane().add(btnCancel);
		
		frmAddSupplier.setVisible(true);
	}

}
