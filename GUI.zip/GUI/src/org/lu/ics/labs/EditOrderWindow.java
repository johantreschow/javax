package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JTextField;

public class EditOrderWindow {

	private JFrame frmChangeOrder;
	private DefaultTableModel tm;
	private JScrollPane scrollPane;
	private Order order;
	private Order backup;
	private JButton btnAddRow;
	private JButton btnDeleteRow;
	private JLabel lblProdukt;
	private JLabel lblAntal;
	private JTextField textFieldProduct;
	private JTextField textFieldAmount;
	private Controller controller;
	private JButton buttonSave;

	/**
	 * Create the application.
	 */
	public EditOrderWindow(Order o, Controller c) {
		controller = c;
		order = o;
		backup = o;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmChangeOrder = new JFrame();
		frmChangeOrder.setTitle("\u00C4ndra Order");
		frmChangeOrder.setBounds(100, 100, 450, 483);
		frmChangeOrder.getContentPane().setLayout(null);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 86, 373, 280);
		frmChangeOrder.getContentPane().add(scrollPane);

		String[] columnNames = new String[] { "Namn", "Antal", "�-pris",
				"totalt pris" };

		tm = new DefaultTableModel();
		tm.setColumnIdentifiers(columnNames);

		JTable table = new JTable(tm);
		scrollPane.setViewportView(table);
		
		
		textFieldProduct = new JTextField();
		textFieldProduct.setBounds(73, 20, 86, 20);
		frmChangeOrder.getContentPane().add(textFieldProduct);
		textFieldProduct.setColumns(10);
		
		textFieldAmount = new JTextField();
		textFieldAmount.setColumns(10);
		textFieldAmount.setBounds(258, 20, 86, 20);
		frmChangeOrder.getContentPane().add(textFieldAmount);

		btnAddRow = new JButton("L\u00E4gg till rad");
		btnAddRow.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnAddRow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product product = controller.getProduct(textFieldProduct.getText());
				if (product == null) {
					JOptionPane.showMessageDialog(frmChangeOrder, "Produkt kan inte hittas.",
							"Fel", 2);
				} else {
					OrderRow row = new OrderRow();
					row.setProduct(product);
					row.setAmount(Integer.parseInt(textFieldAmount.getText()));
					order.addOrderRow(row);
					updateDTM();
				}
			}
		});
		btnAddRow.setBounds(10, 52, 89, 23);
		frmChangeOrder.getContentPane().add(btnAddRow);

		btnDeleteRow = new JButton("Ta bort rad");
		btnDeleteRow.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnDeleteRow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				order.getOrderRows().remove(table.getSelectedRow());
				updateDTM();
			}
		});
		btnDeleteRow.setBounds(109, 51, 89, 23);
		frmChangeOrder.getContentPane().add(btnDeleteRow);
		
		lblProdukt = new JLabel("Produkt: ");
		lblProdukt.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblProdukt.setBounds(28, 23, 46, 14);
		frmChangeOrder.getContentPane().add(lblProdukt);
		
		lblAntal = new JLabel("Antal: ");
		lblAntal.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblAntal.setBounds(220, 23, 46, 14);
		frmChangeOrder.getContentPane().add(lblAntal);
		
		buttonSave = new JButton("Spara");
		buttonSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmChangeOrder.setVisible(false);
				frmChangeOrder.dispose();
			}
		});
		buttonSave.setFont(new Font("Tahoma", Font.PLAIN, 11));
		buttonSave.setBounds(335, 411, 89, 23);
		frmChangeOrder.getContentPane().add(buttonSave);

		updateDTM();

		frmChangeOrder.setVisible(true);

	}

	public void updateDTM() {
		tm.setRowCount(0);
		for (OrderRow tmp : order.getOrderRows()) {
			String[] row = {
					tmp.getProduct().getName(),
					Integer.toString(tmp.getAmount()),
					Double.toString(tmp.getProduct().getPrice()),
					Double.toString(tmp.getProduct().getPrice()
							* tmp.getAmount()) };
			tm.addRow(row);
		}
	}
}
