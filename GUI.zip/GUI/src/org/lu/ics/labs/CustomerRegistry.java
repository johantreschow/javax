package org.lu.ics.labs;

import java.util.HashMap;

public class CustomerRegistry {

	private HashMap<String, Customer> customers = new HashMap<String, Customer>();

	public void addCustomer(String s, Customer c) {
		customers.put(s, c);
	}

	public Customer getCustomer(String customerId) {
		return customers.get(customerId);
	}

	public void removeCustomer(String customerId) {
		customers.remove(customerId);
	}

}
