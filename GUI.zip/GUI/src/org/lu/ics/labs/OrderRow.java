package org.lu.ics.labs;

public class OrderRow {
	
	private Product p;
	private Order o;
	int amount;
	
	public Product getProduct() {
		return p;
	}
	public void setProduct(Product p) {
		this.p = p;
	}
	public Order getOrder() {
		return o;
	}
	public void setOrder(Order o) {
		this.o = o;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
}