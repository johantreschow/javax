package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EditCustomerView {

	private JFrame frmEditCustomer;
	private JTextField textFieldName;
	private JTextField textFieldAdress;
	private JTextField textFieldPhoneNumber;
	private Customer customer;

	/**
	 * Create the application.
	 */
	public EditCustomerView(Customer c) {
		customer = c;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmEditCustomer = new JFrame();
		frmEditCustomer.setTitle("Redigera kund");
		frmEditCustomer.setBounds(100, 100, 450, 183);
		frmEditCustomer.getContentPane().setLayout(null);

		JLabel lblNearestWarehouse = new JLabel("N\u00E4rmaste Lager:");
		lblNearestWarehouse.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNearestWarehouse.setBounds(10, 86, 103, 14);
		frmEditCustomer.getContentPane().add(lblNearestWarehouse);

		JLabel lblPhoneNumber = new JLabel("Telefonnummer:");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPhoneNumber.setBounds(10, 61, 103, 14);
		frmEditCustomer.getContentPane().add(lblPhoneNumber);

		JLabel lblAdress = new JLabel("Adress: ");
		lblAdress.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblAdress.setBounds(10, 36, 103, 14);
		frmEditCustomer.getContentPane().add(lblAdress);

		JLabel lblName = new JLabel("Namn: ");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblName.setBounds(10, 11, 103, 14);
		frmEditCustomer.getContentPane().add(lblName);

		textFieldName = new JTextField();
		textFieldName.setBounds(104, 5, 320, 20);
		frmEditCustomer.getContentPane().add(textFieldName);
		textFieldName.setColumns(10);
		textFieldName.setText(customer.getName());

		textFieldAdress = new JTextField();
		textFieldAdress.setColumns(10);
		textFieldAdress.setBounds(104, 30, 320, 20);
		frmEditCustomer.getContentPane().add(textFieldAdress);
		textFieldAdress.setText(customer.getAdress());

		textFieldPhoneNumber = new JTextField();
		textFieldPhoneNumber.setColumns(10);
		textFieldPhoneNumber.setBounds(104, 55, 320, 20);
		frmEditCustomer.getContentPane().add(textFieldPhoneNumber);
		textFieldPhoneNumber.setText(customer.getPhoneNumber());

		JButton btnSave = new JButton("Spara");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textFieldName.getText().length()
						+ textFieldAdress.getText().length()
						+ textFieldPhoneNumber.getText().length() == 0) {
					JOptionPane.showMessageDialog(frmEditCustomer,
							"Var v�nlig och fyll i alla f�lt.", " ", 2);
				} else {
					customer.setName(textFieldName.getText());
					customer.setAdress(textFieldAdress.getText());
					customer.setPhoneNumber(textFieldPhoneNumber.getText());
					JOptionPane.showMessageDialog(frmEditCustomer,
							"Dina �ndringar har sparats.", " ", 1);
					frmEditCustomer.setVisible(false);
					frmEditCustomer.dispose();
				}
			}
		});
		btnSave.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSave.setBounds(10, 111, 89, 23);
		frmEditCustomer.getContentPane().add(btnSave);

		JButton btnCancel = new JButton("Avbryt");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmEditCustomer.setVisible(false);
				frmEditCustomer.dispose();
			}
		});
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnCancel.setBounds(335, 111, 89, 23);
		frmEditCustomer.getContentPane().add(btnCancel);

		frmEditCustomer.setVisible(true);

	}

}
