package org.lu.ics.labs;

import java.util.HashMap;

public class ProductRegistry {
	
	private HashMap<String, Product> products= new HashMap<String, Product>();

	public void addProduct(String productId, Product p){
		products.put(productId, p);
	}
	
	public Product getProduct(String productId){
		return products.get(productId);
	}
	
	public void removeProduct(String productId){
		products.remove(productId);
	}

}
