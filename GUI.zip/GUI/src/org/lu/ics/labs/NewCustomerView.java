package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class NewCustomerView extends JFrame {

	private JFrame frmAddCustomer;
	private JTextField textFieldPhoneNumber;
	private JTextField textFieldAdress;
	private JTextField textFieldName;
	private Controller controller;
	

	/**
	 * Create the application.
	 */
	public NewCustomerView(Controller c) {
		this.controller = c;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAddCustomer = new JFrame();
		frmAddCustomer.setTitle("L\u00E4gg till kund");
		frmAddCustomer.setBounds(100, 100, 355, 210);
		frmAddCustomer.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Namn: ");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblName.setBounds(20, 43, 46, 14);
		frmAddCustomer.getContentPane().add(lblName);
		
		JLabel lblAdress = new JLabel("Adress: ");
		lblAdress.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblAdress.setBounds(20, 68, 46, 14);
		frmAddCustomer.getContentPane().add(lblAdress);
		
		JLabel lblTelefonnummer = new JLabel("Telefonnummer: ");
		lblTelefonnummer.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblTelefonnummer.setBounds(20, 93, 90, 14);
		frmAddCustomer.getContentPane().add(lblTelefonnummer);
		
		textFieldPhoneNumber = new JTextField();
		textFieldPhoneNumber.setBounds(120, 90, 119, 20);
		frmAddCustomer.getContentPane().add(textFieldPhoneNumber);
		textFieldPhoneNumber.setColumns(10);
		
		textFieldAdress = new JTextField();
		textFieldAdress.setColumns(10);
		textFieldAdress.setBounds(120, 65, 119, 20);
		frmAddCustomer.getContentPane().add(textFieldAdress);
		
		textFieldName = new JTextField();
		textFieldName.setColumns(10);
		textFieldName.setBounds(120, 40, 119, 20);
		frmAddCustomer.getContentPane().add(textFieldName);
		
		JButton btnAdd = new JButton("L\u00E4gg till");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Customer c = new Customer();
				c.setName(textFieldName.getText());
				c.setAdress(textFieldAdress.getText());
				c.setPhoneNumber(textFieldPhoneNumber.getText());
				if(c.getName().length() == 0 || c.getAdress().length() == 0 || c.getPhoneNumber().length() == 0){
					JOptionPane.showMessageDialog(frmAddCustomer, "Var v�nlig och fyll i alla f�lt.", " ", 2);
				}else{
					controller.addCustomer(c);
					Integer customerId = controller.getCustomerId();
					JOptionPane.showMessageDialog(frmAddCustomer, c.getName() + " har kundnummer " + customerId.toString() + ".", " ", 2);
					frmAddCustomer.setVisible(false);
					frmAddCustomer.dispose();
				}
			}
		});
		btnAdd.setBounds(20, 138, 89, 23);
		frmAddCustomer.getContentPane().add(btnAdd);
		
		JButton btnCancel = new JButton("Avbryt");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmAddCustomer.setVisible(false);
				frmAddCustomer.dispose();
			}
		});
		btnCancel.setBounds(240, 138, 89, 23);
		frmAddCustomer.getContentPane().add(btnCancel);
		
		frmAddCustomer.setVisible(true);
	}

}
