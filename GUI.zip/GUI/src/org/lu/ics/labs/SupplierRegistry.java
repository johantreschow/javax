package org.lu.ics.labs;

import java.util.HashMap;

public class SupplierRegistry {
	
	private HashMap<String, Supplier> suppliers = new HashMap<String, Supplier>();
	
	public void addSupplier (String supplierId, Supplier s){
		suppliers.put(supplierId, s);
	}
	
	public Supplier getSupplier(String supplierId){
		return suppliers.get(supplierId);
	}
	
	public void removeSupplier(String supplierId){
		suppliers.remove(supplierId);
	}
}
