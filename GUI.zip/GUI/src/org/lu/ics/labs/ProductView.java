package org.lu.ics.labs;

import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JButton;

import java.awt.Font;

import javax.swing.JList;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ProductView {

	private JFrame frmProductView;
	private JTextField textFieldSearch;
	private Controller controller;
	private Product p;

	/**
	 * Create the application.
	 */
	public ProductView(Controller c) {
		this.controller = c;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmProductView = new JFrame();
		frmProductView.setTitle("Produkt");
		frmProductView.setBounds(100, 100, 561, 623);
		frmProductView.getContentPane().setLayout(null);

		textFieldSearch = new JTextField();
		textFieldSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textFieldSearch.setText("");
			}
		});
		textFieldSearch.setText("S\u00F6k Produkt...");
		textFieldSearch.setBounds(20, 11, 103, 20);
		frmProductView.getContentPane().add(textFieldSearch);
		textFieldSearch.setColumns(10);

		JLabel lblName = new JLabel("Namn: ");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblName.setBounds(20, 68, 389, 14);
		frmProductView.getContentPane().add(lblName);

		JLabel lblPrice = new JLabel("Pris: ");
		lblPrice.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPrice.setBounds(20, 99, 381, 14);
		frmProductView.getContentPane().add(lblPrice);

		JLabel lblWeight = new JLabel("Vikt: ");
		lblWeight.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblWeight.setBounds(20, 130, 381, 14);
		frmProductView.getContentPane().add(lblWeight);

		JLabel lblAntal = new JLabel("Antal: ");
		lblAntal.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblAntal.setBounds(20, 161, 381, 14);
		frmProductView.getContentPane().add(lblAntal);

		JLabel lblRecept = new JLabel("Recept:");
		lblRecept.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblRecept.setBounds(20, 195, 515, 20);
		frmProductView.getContentPane().add(lblRecept);

		JLabel lblProductManager = new JLabel("Produktchef: ");
		lblProductManager.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblProductManager.setBounds(20, 405, 226, 14);
		frmProductView.getContentPane().add(lblProductManager);

		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String productName = textFieldSearch.getText();
				if (productName.length() > 0) {
					Product prodInWarehouse = controller.getWarehouse(
							comboBox.getSelectedIndex())
							.getProduct(productName);
					if (prodInWarehouse == null) {
						lblAntal.setText("Antal: 0");
					} else {
						lblAntal.setText("Antal: "
								+ Integer.toString(prodInWarehouse
										.getAmountInStock()));
					}
				}
			}
		});
		comboBox.setBounds(413, 158, 122, 20);
		frmProductView.getContentPane().add(comboBox);
		for (Warehouse w : controller.getWarehouses().getWarehouses()) {
			comboBox.addItem(w.getName());
		}
		
		JLabel lblRetailNames = new JLabel("F\u00F6rs\u00E4ljningsnamn: ");
		lblRetailNames.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblRetailNames.setBounds(20, 294, 525, 14);
		frmProductView.getContentPane().add(lblRetailNames);

		JButton btnSearch = new JButton("S\u00F6k");
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textFieldSearch.getText().length() == 0) {
					JOptionPane.showMessageDialog(frmProductView,
							"Var v�nlig och fyll i s�kf�ltet.", " ", 2);
				} else {
					p = controller.getProduct(textFieldSearch.getText());
					if (p == null) {
						JOptionPane.showMessageDialog(frmProductView,
								"Produkten kan inte hittas", " ", 2);
					} else {
						lblName.setText("Namn: " + p.getName());
						lblPrice.setText("Pris: "
								+ Double.toString(p.getPrice()));
						lblWeight.setText("Vikt: "
								+ Double.toString(p.getWeight()));
						Product prodInWarehouse = controller.getWarehouse(
								comboBox.getSelectedIndex()).getProduct(
								p.getName());
						if (prodInWarehouse == null) {
							lblAntal.setText("Antal: 0");
						} else {
							lblAntal.setText("Antal: "
									+ prodInWarehouse.getAmountInStock());
						}
						lblRecept.setText("Recept: " + p.getPrepMethod());
						lblProductManager.setText("Produktchef: " + p.getProductManager());
						StringBuilder sb = new StringBuilder();
						for(String str : p.getRetailNames()){
							sb.append(str + ", ");
						}
						lblRetailNames.setText("F�rs�ljningsnamn: " + sb.toString());
					}
				}
			}
		});
		btnSearch.setBounds(133, 10, 89, 23);
		frmProductView.getContentPane().add(btnSearch);

		JButton btnUpdateStock = new JButton("Uppdatera Lagersaldo");
		btnUpdateStock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (p != null) {
					UpdateStockView updateStock = new UpdateStockView(
							controller, p);
				}
			}
		});
		btnUpdateStock.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnUpdateStock.setBounds(379, 10, 156, 23);
		frmProductView.getContentPane().add(btnUpdateStock);
		
		JButton btnEdit = new JButton("Redigera");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(p == null){
					JOptionPane.showMessageDialog(frmProductView,
							"Var v�nlig och s�k fram en produkt innan du redigerar.", " ", 2);
				}else {
					EditProductView editProductView = new EditProductView(controller, p);
				}
			}
		});
		btnEdit.setBounds(232, 10, 89, 23);
		frmProductView.getContentPane().add(btnEdit);
		
		DefaultListModel listModel = new DefaultListModel();

		frmProductView.setVisible(true);
	}
}
