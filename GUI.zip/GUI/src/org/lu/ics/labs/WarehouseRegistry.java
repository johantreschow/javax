package org.lu.ics.labs;

import java.util.ArrayList;

public class WarehouseRegistry {
	
	private ArrayList<Warehouse> warehouses = new ArrayList<Warehouse>();
	
	public void addWarehouse(Warehouse w){
		warehouses.add(w);
	}
	
	public Warehouse getWarehouse(int index){
		return warehouses.get(index);
	}
	
	public void removeWarehouse(Warehouse w){
		warehouses.remove(w);
	}

	public ArrayList<Warehouse> getWarehouses() {
		return warehouses;
	}

	public void setWarehouses(ArrayList<Warehouse> warehouses) {
		this.warehouses = warehouses;
	}

	
	

}
