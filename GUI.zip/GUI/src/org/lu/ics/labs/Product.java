package org.lu.ics.labs;

import java.util.ArrayList;
import java.util.HashMap;

public class Product {
	private String name;
	private double price;
	private double weight;
	private int amountInStock = 0;
	private String productManager;
	private String ingredients;
	private String prepMethod;
	private ArrayList<String> retailNames = new ArrayList<>();
	private HashMap<String, Supplier> suppliers = new HashMap<String, Supplier>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public int getAmountInStock() {
		return amountInStock;
	}

	public void setAmountInStock(int amountInStock) {
		this.amountInStock = amountInStock;
	}

	public String getProductManager() {
		return productManager;
	}

	public void setProductManager(String productManager) {
		this.productManager = productManager;
	}

	public String getIngredients() {
		return ingredients;
	}

	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}

	public String getPrepMethod() {
		return prepMethod;
	}

	public void setPrepMethod(String prepMethod) {
		this.prepMethod = prepMethod;
	}

	public ArrayList<String> getRetailNames() {
		return retailNames;
	}

	public void setRetailNames(ArrayList<String> retailNames) {
		this.retailNames = retailNames;
	}

	public void addRetailName(String name) {
		retailNames.add(name);
	}

	public void removeRetailName(String name) {
		retailNames.remove(name);
	}
	
	public void addSupplier(Supplier supplier){
		suppliers.put(supplier.getName(), supplier);
	}
	
	public Supplier getSupplier(String supplierName){
		return suppliers.get(supplierName);
	}
	
	public void removeSupplier(String supplierName){
		suppliers.remove(supplierName);
	}
}