package org.lu.ics.labs;

import java.util.ArrayList;

public class Customer {
	private String name;
	private String customerId;
	private String phoneNumber;
	private String adress;
	private String salesTerms;
	private ArrayList<Order> orders = new ArrayList<>();

	public ArrayList<Order> getOrders() {
		return orders;
	}

	public void setOrders(ArrayList<Order> orders) {
		this.orders = orders;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getSalesTerms() {
		return salesTerms;
	}

	public void setSalesTerms(String salesTerms) {
		this.salesTerms = salesTerms;
	}

	public void addOrder(Order order) {
		orders.add(order);
	}

	public void removeOrder(Order order) {
		orders.remove(order);
	}
}