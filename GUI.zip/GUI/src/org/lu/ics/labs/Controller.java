package org.lu.ics.labs;

public class Controller {

	private CustomerRegistry customers = new CustomerRegistry();
	private SupplierRegistry suppliers = new SupplierRegistry();
	private ProductRegistry products = new ProductRegistry();
	private WarehouseRegistry warehouses = new WarehouseRegistry();
	private int orderId = 0;

	public WarehouseRegistry getWarehouses() {
		return warehouses;
	}

	public void setWarehouses(WarehouseRegistry warehouses) {
		this.warehouses = warehouses;
	}

	private int customerId = 0;

	public void addCustomer(Customer c) {
		String customerId = Integer.toString(getNextCustomerId());
		customers.addCustomer(customerId, c);
	}

	public Customer getCustomer(String customerId) {
		return customers.getCustomer(customerId);
	}

	public void removeCustomer(String customerId) {
		customers.removeCustomer(customerId);
	}

	public void addSupplier(Supplier s) {
		suppliers.addSupplier(s.getName(), s);
	}

	public Supplier getSupplier(String supplierId) {
		return suppliers.getSupplier(supplierId);
	}

	public void removeSupplier(String supplierId) {
		suppliers.removeSupplier(supplierId);
	}

	public void addProduct(String productId, Product p) {
		products.addProduct(productId, p);
		for (Warehouse tmp : warehouses.getWarehouses()) {
			tmp.addProduct(p);
		}
	}

	public Product getProduct(String productId) {
		return products.getProduct(productId);
	}

	public void removeProduct(String productId) {
		products.removeProduct(productId);
	}

	public void addWarehouse(Warehouse w) {
		warehouses.addWarehouse(w);
	}

	public Warehouse getWarehouse(int index) {
		return warehouses.getWarehouse(index);
	}

	public void removeWarehouse(Warehouse w) {
		warehouses.removeWarehouse(w);
	}

	public int getNextCustomerId() {
		customerId++;
		return customerId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public int getOrderId() {
		orderId++;
		return orderId;
	}

}
