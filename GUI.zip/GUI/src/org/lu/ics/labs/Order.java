package org.lu.ics.labs;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Order {
	private String orderId;
	private String date;
	private String status;
	private Customer customer;
	private ArrayList<OrderRow> orderRows = new ArrayList<OrderRow>();
	
	public Order(int orderId){
		status = "Order mottagen";
		this.orderId = Integer.toString(orderId);
		date  = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public ArrayList<OrderRow> getOrderRows() {
		return orderRows;
	}

	public void setOrderRows(ArrayList<OrderRow> orderRows) {
		this.orderRows = orderRows;
	}

	public void addOrderRow(OrderRow row) {
		orderRows.add(row);
	}

	public void removeOrderRow(OrderRow row) {
		orderRows.remove(row);
	}
}
