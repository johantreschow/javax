package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NewProductView{

	private JFrame frmAddProduct;
	private JTextField textFieldName;
	private JTextField textFieldPrice;
	private JTextField textFieldWeight;
	private Controller controller;


	/**
	 * Create the application.
	 */
	public NewProductView(Controller c) {
		this.controller = c;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAddProduct = new JFrame();
		frmAddProduct.setTitle("L\u00E4gg till produkt");
		frmAddProduct.setBounds(100, 100, 347, 233);
		frmAddProduct.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Namn:");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblName.setBounds(21, 39, 46, 14);
		frmAddProduct.getContentPane().add(lblName);
		
		JLabel lblPrice = new JLabel("Pris (kr): ");
		lblPrice.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPrice.setBounds(21, 63, 46, 14);
		frmAddProduct.getContentPane().add(lblPrice);
		
		JLabel lblWeight = new JLabel("Vikt (kg):");
		lblWeight.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblWeight.setBounds(21, 88, 46, 14);
		frmAddProduct.getContentPane().add(lblWeight);
		
		textFieldName = new JTextField();
		textFieldName.setBounds(102, 36, 86, 20);
		frmAddProduct.getContentPane().add(textFieldName);
		textFieldName.setColumns(10);
		
		textFieldPrice = new JTextField();
		textFieldPrice.setColumns(10);
		textFieldPrice.setBounds(102, 60, 86, 20);
		frmAddProduct.getContentPane().add(textFieldPrice);
		
		textFieldWeight = new JTextField();
		textFieldWeight.setColumns(10);
		textFieldWeight.setBounds(102, 85, 86, 20);
		frmAddProduct.getContentPane().add(textFieldWeight);
		
		JButton btnAddProduct = new JButton("L\u00E4gg till");
		btnAddProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(controller.getProduct(textFieldName.getText()) == null){
					Product p = new Product();											//Skapar produkt
					p.setName(textFieldName.getText());									//S�tter namnet p� produkten till namnet i textrutan
					p.setPrice(Double.parseDouble(textFieldPrice.getText()));			//Konverterar om textstr�ngen (String) i rutan f�r pris och s�tter produktens pris till detta
					p.setWeight(Double.parseDouble(textFieldWeight.getText()));			//Konverterar om textstr�ngen till en double och l�gger in den som vikt f�r produkten
					if(p.getName().length() == 0 || textFieldPrice.getText().length() == 0 || textFieldWeight.getText().length() == 0){
						JOptionPane.showMessageDialog(frmAddProduct, "Var v�nlig och fyll i alla f�lt.", " ", 2);
					}else {
						controller.addProduct(p.getName(), p);								//L�gger till produkten i registret
						frmAddProduct.setVisible(false);
						frmAddProduct.dispose();
					}
					
				}else{
					JOptionPane.showMessageDialog(frmAddProduct, "Produkt finns redan.", "Fel", 2);
				}
			}
		});
		btnAddProduct.setBounds(10, 161, 89, 23);
		frmAddProduct.getContentPane().add(btnAddProduct);
		
		JButton btnCancel = new JButton("Avbryt");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmAddProduct.setVisible(false);
				frmAddProduct.dispose();
			}
		});
		btnCancel.setBounds(232, 161, 89, 23);
		frmAddProduct.getContentPane().add(btnCancel);
		
		frmAddProduct.setVisible(true);
	}
}
