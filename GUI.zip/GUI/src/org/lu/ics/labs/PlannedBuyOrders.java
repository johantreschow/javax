package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;

public class PlannedBuyOrders {

	private JFrame frmPlannedBuyOrders;
	private Controller controller;


	/**
	 * Create the application.
	 */
	public PlannedBuyOrders(Controller c) {
		this.controller = c;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPlannedBuyOrders = new JFrame();
		frmPlannedBuyOrders.setTitle("Planerade ink\u00F6p");
		frmPlannedBuyOrders.setBounds(100, 100, 553, 397);
		frmPlannedBuyOrders.setVisible(true);
	}
	

}
