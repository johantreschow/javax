package org.lu.ics.labs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JEditorPane;
import javax.swing.JTextPane;

import java.awt.TextArea;
import java.awt.Button;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JComboBox;

public class EditProductView {

	private JFrame frmRedigeraProdukt;
	private JTextField textFieldProductManager;
	private JTextField textFieldWeight;
	private JTextField textFieldPrice;
	private JTextField textFieldName;
	private Controller controller;
	private JTextField textFieldRetailName;
	private Product product;

	public EditProductView(Controller c, Product p) {
		product = p;
		controller = c;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmRedigeraProdukt = new JFrame();
		frmRedigeraProdukt.setTitle("Redigera Produkt");
		frmRedigeraProdukt.setBounds(100, 100, 578, 556);
		frmRedigeraProdukt.getContentPane().setLayout(null);

		JLabel lblName = new JLabel("Namn: ");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblName.setBounds(10, 39, 46, 14);
		frmRedigeraProdukt.getContentPane().add(lblName);

		JLabel lblPrice = new JLabel("Pris: ");
		lblPrice.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPrice.setBounds(10, 64, 46, 14);
		frmRedigeraProdukt.getContentPane().add(lblPrice);

		JLabel lblWeight = new JLabel("Vikt: ");
		lblWeight.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblWeight.setBounds(10, 89, 46, 14);
		frmRedigeraProdukt.getContentPane().add(lblWeight);

		JLabel lblProductManager = new JLabel("Produktchef:");
		lblProductManager.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblProductManager.setBounds(10, 114, 95, 14);
		frmRedigeraProdukt.getContentPane().add(lblProductManager);

		textFieldProductManager = new JTextField();
		textFieldProductManager.setBounds(115, 111, 208, 20);
		frmRedigeraProdukt.getContentPane().add(textFieldProductManager);
		textFieldProductManager.setColumns(10);
		textFieldProductManager.setText(product.getProductManager());

		textFieldWeight = new JTextField();
		textFieldWeight.setColumns(10);
		textFieldWeight.setBounds(115, 86, 208, 20);
		frmRedigeraProdukt.getContentPane().add(textFieldWeight);
		textFieldWeight.setText(Double.toString(product.getWeight()));

		textFieldPrice = new JTextField();
		textFieldPrice.setColumns(10);
		textFieldPrice.setBounds(115, 61, 208, 20);
		frmRedigeraProdukt.getContentPane().add(textFieldPrice);
		textFieldPrice.setText(Double.toString(product.getPrice()));

		textFieldName = new JTextField();
		textFieldName.setColumns(10);
		textFieldName.setBounds(115, 36, 208, 20);
		frmRedigeraProdukt.getContentPane().add(textFieldName);
		textFieldName.setText(product.getName());

		JLabel lblRetailNames = new JLabel("F\u00F6rs\u00E4ljningsnamn:");
		lblRetailNames.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblRetailNames.setBounds(10, 158, 95, 14);
		frmRedigeraProdukt.getContentPane().add(lblRetailNames);

		JLabel lblPrepMethod = new JLabel("Recept: ");
		lblPrepMethod.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPrepMethod.setBounds(10, 253, 95, 14);
		frmRedigeraProdukt.getContentPane().add(lblPrepMethod);

		TextArea textAreaPrepMethod = new TextArea();
		textAreaPrepMethod.setBounds(115, 253, 380, 160);
		frmRedigeraProdukt.getContentPane().add(textAreaPrepMethod);
		textAreaPrepMethod.setText(product.getPrepMethod());

		JButton btnSave = new JButton("Spara");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textFieldName.getText().length() > 0) {
					controller.removeProduct(product.getName());
					product.setName(textFieldName.getText());
					controller.addProduct(product.getName(), product);
					if (textFieldPrice.getText().length() > 0) {
						product.setPrice(Double.parseDouble(textFieldPrice
								.getText()));
						if (textFieldWeight.getText().length() > 0) {
							product.setWeight(Double
									.parseDouble(textFieldWeight.getText()));
							if (textFieldProductManager.getText().length() > 0) {
								product.setProductManager(textFieldProductManager
										.getText());
								product.setPrepMethod(textAreaPrepMethod
										.getText());
								JOptionPane.showMessageDialog(
										frmRedigeraProdukt,
										"�ndringarna har sparats", " ", 1);
								frmRedigeraProdukt.setVisible(false);
								frmRedigeraProdukt.dispose();
							} else {
								JOptionPane
										.showMessageDialog(
												frmRedigeraProdukt,
												"Var v�nlig och fyll i en produktchef f�r produkten",
												" ", 2);
							}
						} else {
							JOptionPane
									.showMessageDialog(
											frmRedigeraProdukt,
											"Var v�nlig och fyll i vikten f�r produkten",
											" ", 2);
						}
					} else {
						JOptionPane.showMessageDialog(frmRedigeraProdukt,
								"Var v�nlig och fyll i priset f�r produkten",
								" ", 2);
					}

				} else {
					JOptionPane.showMessageDialog(frmRedigeraProdukt,
							"Var v�nlig och fyll i namnet f�r produkten", " ",
							2);
				}
			}
		});
		btnSave.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSave.setBounds(10, 484, 89, 23);
		frmRedigeraProdukt.getContentPane().add(btnSave);

		JButton btnCancel = new JButton("Avbryt");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmRedigeraProdukt.setVisible(false);
				frmRedigeraProdukt.dispose();
			}
		});
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnCancel.setBounds(463, 484, 89, 23);
		frmRedigeraProdukt.getContentPane().add(btnCancel);

		textFieldRetailName = new JTextField();
		textFieldRetailName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textFieldRetailName.setBounds(115, 155, 208, 20);
		frmRedigeraProdukt.getContentPane().add(textFieldRetailName);
		textFieldRetailName.setColumns(10);

		JComboBox comboBoxListRetailNames = new JComboBox();
		comboBoxListRetailNames.setBounds(115, 186, 208, 20);
		frmRedigeraProdukt.getContentPane().add(comboBoxListRetailNames);
		for (String tmp : product.getRetailNames()) {
			comboBoxListRetailNames.addItem(tmp);
		}

		JButton btnAddRetailName = new JButton(
				"L\u00E4gg till F\u00F6rs\u00E4ljningsnamn");
		btnAddRetailName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String retailName = textFieldRetailName.getText();
				if (retailName.length() == 0) {
					JOptionPane.showMessageDialog(frmRedigeraProdukt,
							"Var v�nlig fyll i ett f�rs�ljningsnamn" + "",
							"Fel", 2);
				} else {
					product.addRetailName(retailName);
					comboBoxListRetailNames.addItem(retailName);
				}
			}
		});
		btnAddRetailName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnAddRetailName.setBounds(350, 154, 173, 23);
		frmRedigeraProdukt.getContentPane().add(btnAddRetailName);

		JButton btnRemoveRetailName = new JButton(
				"Ta Bort F\u00F6rs\u00E4ljningsnamn");
		btnRemoveRetailName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String retailName = product.getRetailNames().get(
						comboBoxListRetailNames.getSelectedIndex());
				if (JOptionPane
						.showConfirmDialog(null, "Ta bort f�rs�ljningsnamn?",
								"�r du s�ker p� att du vill ta bort namnet "
										+ retailName + " ur listan?",
								JOptionPane.YES_NO_OPTION,
								JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
					product.getRetailNames().remove(
							comboBoxListRetailNames.getSelectedIndex());
					comboBoxListRetailNames.removeItem(retailName);
				} else {
				}
			}
		});
		btnRemoveRetailName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnRemoveRetailName.setBounds(350, 185, 173, 23);
		frmRedigeraProdukt.getContentPane().add(btnRemoveRetailName);

		frmRedigeraProdukt.setVisible(true);
	}
}
